CREATE TABLE DimHost (
    Host_id INT PRIMARY KEY,
    Host_name NVARCHAR(50) NOT NULL,
    Host_since DATE,
    Host_location NVARCHAR(50),
    Host_response_time NVARCHAR(50),
    Host_response_rate NVARCHAR(50),
    Host_acceptance_rate NVARCHAR(50),
    Host_is_superhost NVARCHAR(3),
    Host_verifications NVARCHAR(50),
    Host_has_profile_pic NVARCHAR(3),
    Host_identity_verified BIT
);

INSERT INTO DimHost (Host_name, Host_since, Host_location, Host_response_time, 
                     Host_response_rate, Host_acceptance_rate, Host_is_superhost, 
                     Host_verifications, Host_has_profile_pic, Host_identity_verified)
SELECT DISTINCT 
      L.Host_name, L.Host_since, L.Host_location, L.Host_response_time, 
       L.Host_response_rate, L.Host_acceptance_rate, L.Host_is_superhost, 
       L.Host_verifications, L.Host_has_profile_pic, L.Host_identity_verified
FROM listings L



SELECT DISTINCT 
    id AS listing_id,  
    Review_scores_rating, 
    Review_scores_accuracy, 
    Review_scores_cleanliness, 
    Review_scores_communication, 
    Review_scores_location, 
    Review_scores_value
INTO DimReviewScores
FROM Listings;






CREATE TABLE DimPropertyType (
    Property_type_id INT IDENTITY(1,1) PRIMARY KEY,
    Property_type NVARCHAR(100) NOT NULL
);
INSERT INTO DimPropertyType (Property_type)
SELECT DISTINCT Property_type FROM Listings;

CREATE TABLE DimRoomType (
    Room_type_id INT IDENTITY(1,1) PRIMARY KEY,
    Room_type NVARCHAR(50) NOT NULL
);
INSERT INTO DimRoomType (Room_type)
SELECT DISTINCT Room_type FROM Listings;



SELECT DISTINCT Reviewer_id, Reviewer_name
INTO dimreviewer
FROM reviews;



CREATE TABLE DimListings (
    Listing_id INT PRIMARY KEY,
    Name NVARCHAR(255),
    Description NVARCHAR(MAX),
    Property_type_id INT FOREIGN KEY REFERENCES DimPropertyType(Property_type_id),
    Room_type_id INT FOREIGN KEY REFERENCES DimRoomType(Room_type_id),
    Host_id INT FOREIGN KEY REFERENCES DimHost(Host_id),
    Accommodates INT,
    Price BIGINT,
    Minimum_nights SMALLINT,
    Maximum_nights SMALLINT,
    Latitude FLOAT,
    Longitude FLOAT,
    Instant_bookable VARCHAR(3)
);



INSERT INTO DimListings (Listing_id, Name, Description, Property_type_id, Room_type_id, Accommodates, 
                         Price, Minimum_nights, Maximum_nights, Latitude, Longitude, Instant_bookable, Host_id)
SELECT L.id, L.Name, L.Description, P.Property_type_id, R.Room_type_id, L.Accommodates, 
       L.Price, L.Minimum_nights, L.Maximum_nights, L.Latitude, L.Longitude, L.Instant_bookable, H.Host_id
FROM Listings L
JOIN DimPropertyType P ON L.Property_type = P.Property_type
JOIN DimRoomType R ON L.Room_type = R.Room_type
JOIN DimHost H ON L.Host_id = H.Host_id;

SELECT 
    C.Listing_id, 
    C.Date,         
    C.Available,   
    L.Price,        
    C.Adjusted_Price,  
    L.Minimum_Nights,   
    L.Maximum_Nights   
INTO Calendar_Fact
FROM Listings L
LEFT JOIN Calendar C ON L.id = C.Listing_id;

   SELECT 
    R.ID AS Review_ID,  
    D.Listing_ID,  
    R.Date,  
    R.Comments 
INTO Reviews_Fact 
FROM Reviews R
LEFT JOIN DimListings D ON R.Listing_id = D.Listing_ID;








Poioi Hosts ehoun ta perissotera Listings?

SELECT H.Host_name, COUNT(L.Listing_id) AS Total_Listings
FROM DimHost H
JOIN DimListings L ON H.Host_id = L.Host_id
GROUP BY H.Host_name
ORDER BY Total_Listings DESC;

Mesi timi enoikiasis ana typo katalimatos

SELECT P.Property_type, AVG(L.Price) AS Avg_Price
FROM DimListings L
JOIN DimPropertyType P ON L.Property_type_id = P.Property_type_id
GROUP BY P.Property_type
ORDER BY Avg_Price DESC;

Poies kataxwriseis anikoun se Superhosts?

SELECT L.Name, L.Price, H.Host_name
FROM DimListings L
JOIN DimHost H ON L.Host_id = H.Host_id
WHERE H.Host_is_superhost = 'Yes';